library(shiny)
library(dplyr)
library(readr)
library(tidyr)
library(ggplot2)
library(googleVis)
library(leaflet)
library(maps)


wine = read_csv("winemag-data.csv")

###############################
#---------SETUP DF------------#

wine_df = cbind(wine[2:10],wine[12:14])
wine_df = wine_df %>%
  drop_na(points,price,country,variety) %>%
  mutate(country = as.factor(country),
         province = as.factor(province),
         taster_name = as.factor(taster_name),
         variety = as.factor(variety)) %>%
  mutate(price_range = case_when(price <= 10 ~ "< $10",
                                 price <=25 & price > 10 ~ "$10-$25",
                                 price <=50 & price > 25 ~ "$25-$50",
                                 price <=100 & price > 50 ~ "$50-$100",
                                 price <=500 & price >100 ~ "$100-$500",
                                 price > 500 ~ "> $500"))

ave_scores = wine_df %>%
  group_by(title) %>%
  summarise(ave_score = as.integer(mean(points)))

joined = inner_join(wine_df,ave_scores, by = 'title')

wine_df = joined %>%
  mutate(point_range = case_when(ave_score <= 85 ~ "< 85",
                                 ave_score <= 90 & ave_score > 85 ~ "85-90",
                                 ave_score <= 95 & ave_score > 90 ~ "90-95",
                                 ave_score <=100 & ave_score > 95 ~ "95-100")) %>%
  mutate(price_range = as.factor(price_range), 
         point_range = as.factor(point_range))  ## -->best df for analysis

rm(joined, wine, ave_scores)

top_varieties = wine_df %>% 
  group_by(variety) %>% 
  distinct(title) %>%
  summarise(count = n()) %>% 
  arrange(desc(count)) %>% 
  top_n(25,count) %>%
  select(variety)
###############################
#---------MAPPING------------#


map("world", fill = TRUE, plot = FALSE)

