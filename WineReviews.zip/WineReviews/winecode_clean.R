library(dplyr)
library(readr)
library(tidyr)
library(ggplot2)

#install.packages("RColorBrewer")
library(RColorBrewer)
#display.brewer.all()
#install.packages("mapproj")
library(mapproj)

wine = read_csv("winemag-data.csv")

###############################
#---------SETUP DF------------#

wine_df = cbind(wine[2:10],wine[12:14])
wine_df = wine_df %>% 
  drop_na(points,price)
wine_df = wine_df %>% 
  mutate(country = as.factor(country),
         province = as.factor(province),
         taster_name = as.factor(taster_name),
         variety = as.factor(variety))

wine_df = wine_df %>% 
  mutate(price_range = case_when(price <= 10 ~ "< $10", 
                                 price <=25 & price > 10 ~ "$10-$25",
                                 price <=50 & price > 25 ~ "$25-$50",
                                 price <=100 & price > 50 ~ "$50-$100",
                                 price <=500 & price >100 ~ "$100-$500",
                                 price > 500 ~ "> $500"))

ave_scores = wine_df %>%
  group_by(title) %>% 
  summarise(ave_score = as.integer(mean(points)))

joined = inner_join(wine_df,ave_scores, by = 'title')

wine_df = joined %>% 
  mutate(point_range = case_when(ave_score <= 85 ~ "< 85", 
                                 ave_score <= 90 & ave_score > 85 ~ "85-90",
                                 ave_score <= 95 & ave_score > 90 ~ "90-95",
                                 ave_score <=100 & ave_score > 95 ~ "95-100"))

wine_df = wine_df %>% 
  mutate(price_range = as.factor(price_range), point_range = as.factor(point_range))  ##best df to analyze
     ## can I save this cleaned version as *.Rdata?

###############################
#----------INPUTS-------------#
input_variety = 'Pinot Noir'  #take from top_variety selector df
input_country = 'Argentina'  #take from top_country selector df
input_pricerange = '$10-$25'  #take from top_variety selector df

###############################
#---------SELECTORS-------------#

top_varieties = wine_df %>% 
  group_by(variety) %>% 
  distinct(title) %>%
  summarise(count = n()) %>% 
  arrange(desc(count)) %>% 
 top_n(25,count) %>%
 select(variety)

wine_countries = wine_df %>% 
  group_by(country) %>% 
  drop_na(country) %>%
  summarise(count = n()) %>% 
  arrange(desc(count)) %>% 
  select(country)

tasters = wine_df %>%
  select(taster_name) %>%
  drop_na(taster_name) %>%
  distinct(taster_name)

###############################
#----------OUTPUTS-------------#


#----------LISTS-------------#

#A - top 10 best scoring wines by variety
#B - top 10 best scoring wines by price range
#C - combo of A&B?
#D - list of varieties in a region/country (chosen on map)


#----------GRAPHS-------------#

#1 - map locations

#2 - graph comparison of reviewers' scores for different wines

#3 - graph of price vs score for specified variety

var_price_vs_score = wine_df %>% filter(variety == input_variety)
  
ggplot(data = var_price_vs_score, aes(x=ave_score,y=price)) + 
  geom_point(aes(color=price)) 

#filter out highest prices:
ggplot(data = var_price_vs_score, aes(x=ave_score,y=price)) + 
  geom_point(aes(color=price)) + coord_cartesian(ylim = c(0,750))


wine_df %>% filter(country == is.na(country))

